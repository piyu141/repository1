import { Component } from "@angular/core";


@Component({
    selector:'feature-one',
    templateUrl:"./feature.component.html",
    styleUrls:["./feature.component.css"]
})



export class FeatureComponent{}